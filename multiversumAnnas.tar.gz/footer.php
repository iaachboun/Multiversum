<div class="Footer">
    <div class="contact">
        <ul>
            <li>Facebook</li>
            <li>Instagram</li>
            <li>LinkedIn</li>
            <li>E-mail</li>
        </ul>
    </div>
</div>

</body>
</html>
