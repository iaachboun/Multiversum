<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="build/assets/style/app.css" type="text/css">
    <title>Title</title>
</head>
<body>
<div class="aanmelden" style="float: right">

    <form method="post" action="eigen_website.php">
        <input type="text" name="naam" placeholder="Naam"> <br>
        <input type="text" name="achternaam" placeholder="Achternaam"> <br>
        <input type="password" name="code" placeholder="pincode"><br>
        <input type="submit" name="login" value="Login">

    </form>
</div>
<div class="header">
    <div class="logo">
        <img src="assets/img/logo.jpg">
    </div>
    <div class="nav">
        <ul>
            <li><a href="#">Home</a><div class="line"></div></li>
            <li><a href="#">Page2</a><div class="line"></div></li>
            <li><a href="#">Page3</a><div class="line"></div></li>
            <li><a href="#">Contact</a><div class="line"></div></li>
        </ul>
    </div>
</div>
