<?php

include 'header.php';
include 'view/home/ProductOverzicht.php';

// require('./controller/pageController.php');

// $controller = new ContactsController();
// $controller->handleRequest();


include 'footer.php';
